namespace TripViewer.Utility
{

    public class TripViewerConfiguration
    {
        public string USERPROFILE_API_ENDPOINT { get; set; }
        public string TRIPS_API_ENDPOINT { get; set; }
        public string BING_MAPS_KEY { get; set; }
    }
}